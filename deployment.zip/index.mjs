export const handler = async (event) => {
    const response = {
        statusCode: 200,
        message: 'This is an update on the develop branch for UAT - full cicd 2h'
    };
    return response;
};